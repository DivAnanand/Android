package com.example.dailyreport2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class JeevanEA extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jeevan_e);


    }
}