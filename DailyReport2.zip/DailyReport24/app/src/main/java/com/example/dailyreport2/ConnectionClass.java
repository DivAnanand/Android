package com.example.dailyreport2;

public class ConnectionClass {
    
}
